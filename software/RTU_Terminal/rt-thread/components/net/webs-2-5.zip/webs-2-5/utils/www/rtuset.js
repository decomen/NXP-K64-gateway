

var xhr;
var xTcpipCfgList = new Array();
var xUartCfgList = new Array();
var xVarManageExtDataBase = new Array();
var xProtoDevList = new Array();

function createXMLHttpRequest() {
    var request = false;
    if(window.XMLHttpRequest) {
        request = new XMLHttpRequest();
        if(request.overrideMimeType) {
            request.overrideMimeType('text/xml');
        }
    } else if(window.ActiveXObject) {
        var versions = ['Microsoft.XMLHTTP', 'MSXML.XMLHTTP', 'Microsoft.XMLHTTP', 'Msxml2.XMLHTTP.7.0', 'Msxml2.XMLHTTP.6.0', 'Msxml2.XMLHTTP.5.0', 'Msxml2.XMLHTTP.4.0', 'MSXML2.XMLHTTP.3.0', 'MSXML2.XMLHTTP'];
        for(var i=0; i<versions.length; i++) {
            try {
                request = new ActiveXObject(versions[i]);
                if(request) {
                    return request;
                }
            } catch(e) {}
        }
    }
    return request;
}

function getNumber( id )
{
    return Number(window.document.getElementById(id).value);
}

function getValue( id )
{
    return window.document.getElementById(id).value;
}


function setValue( id, val )
{
    window.document.getElementById(id).value=val;
}

function setEnable( id, enable )
{
    window.document.getElementById(id).disabled=!enable;
}

function setVisible( id, visible )
{
    window.document.getElementById(id).style.visibility=visible?"visible":"hidden";
}

function initSetting()
{
    getDevInfo();
    onUartCfgMsChange(0);
    onUartCfgMsChange(1);
    onUartCfgMsChange(2);
    onUartCfgMsChange(3);
}

function onUartCfgMsChange(n)
{
    var po = getNumber('uart' + n + '_cfg_proto');
    var ms = getNumber('uart' + n + '_cfg_ms');
    
    if( ms != null && po != null && po == 0 && ms == 0 ) {
        setVisible( 'uart'+ n + '_cfg_addr_lb', true );
        setVisible( 'uart'+ n + '_cfg_addr', true );
    } else {
        setVisible( 'uart'+ n + '_cfg_addr_lb', false );
        setVisible( 'uart'+ n + '_cfg_addr', false );
    }
}

function setUartHtml(n, bd, ut, po, py, ms, ad)
{
    if( bd != null ) setValue('uart' + n + '_cfg_baud', bd); 
    if( ut != null ) setValue('uart' + n + '_cfg_mode', ut); 
    if( po != null ) setValue('uart' + n + '_cfg_proto', po); 
    if( py != null ) setValue('uart' + n + '_cfg_parity', py); 
    if( ms != null ) setValue('uart' + n + '_cfg_ms', ms); 
    if( ad != null ) setValue('uart' + n + '_cfg_addr', ad);
    
    onUartCfgMsChange(n);
}

function setUartCfg(i)
{
    var setval = {
        n:Number(i), 
        bd:getNumber('uart' + i + '_cfg_baud'), 
        ut:getNumber('uart' + i + '_cfg_mode'), 
        po:getNumber('uart' + i + '_cfg_proto'), 
        py:getNumber('uart' + i + '_cfg_parity'), 
        ms:getNumber('uart' + i + '_cfg_ms'), 
        ad:getNumber('uart' + i + '_cfg_addr')
    };

    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        alert( "���óɹ�" );
                    } else {
                        alert("����ʧ��,������");
                    }
                } else {
                    alert("���ó�ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/setUartCfgForm?arg=" + JSON.stringify(setval) );
		xhr.send();
	}
}

function getAllUartCfg()
{
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        xUartCfgList = res.list.concat();
                        for( var n = 0; n < res.list.length; n++ ) {
                            setUartHtml( 
                                n, 
                                res.list[n].bd, 
                                res.list[n].ut, 
                                res.list[n].po, 
                                res.list[n].py, 
                                res.list[n].ms, 
                                res.list[n].ad
                            );
                        }
                    } else {
                        alert("��ȡʧ��,������");
                    }
                } else {
                    alert("��ȡ��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getUartCfgForm?arg={\"all\":1}" );
		xhr.send();
	}
}

function getUartCfg(i)
{
    var setval = { n:Number(i) };
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        setUartHtml( i, res.bd, res.ut, res.po, res.py, res.ms, res.ad );
                    } else {
                        alert("��ȡʧ��,������");
                    }
                } else {
                    alert("��ȡ��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getUartCfgForm?arg=" + JSON.stringify(setval) );
		xhr.send();
	}
}

function getAllVarManageExtDataBase()
{
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        xVarManageExtDataBase = res.list.concat();
                        xProtoDevList = res.protolist;
                        refreshProtoDevList( res.protolist );
                        varExtTableItemRemoveAll();
                        for( var n = 0; n < res.list.length; n++ ) {
                            varExtTableAddItem( 
                                res.list[n].en, 
                                res.list[n].na, 
                                res.list[n].al, 
                                res.list[n].vt, 
                                res.list[n].vs, 
                                res.list[n].it, 
                                res.list[n].va, 
                                res.list[n].dt, 
                                res.list[n].pt
                            );
                        }
                        var table = window.document.getElementById("rtu_var_ext_table");
                        onExtTableItemClick(table, table.rows[0]);
                    } else {
                        alert("��ȡʧ��,������");
                    }
                } else {
                    alert("��ȡ��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getVarManageExtDataForm?arg={\"all\":1}" );
		xhr.send();
	}
}

function getVarExtInfo()
{
    var obj = window.document.getElementById("var_ext_id");
    var id = -1;
    if( obj != null && obj.value.length > 0 ) {
        id = Number(obj.value);
    }
    
    if( id >= 0 && id <= 64 ) {
        var setval = { n:Number(id) };
        xhr = createXMLHttpRequest();
        if (xhr) {
            xhr.onreadystatechange = function() {
                if( xhr.readyState==4 ) {
                    if( xhr.status==200 ) {
                        var res = JSON.parse(xhr.responseText);
                        if( res && 0 == res.ret ) {
                            if( xVarManageExtDataBase[id] != null ) {
                                xVarManageExtDataBase[id] = res;
                            }
                            var table = window.document.getElementById("rtu_var_ext_table");
                            onExtTableItemClick(table, table.rows[id]);
                        } else {
                            alert("��ȡʧ��,������");
                        }
                    } else {
                        alert("��ȡ��ʱ,������");
                    }
                }
            }
            xhr.open("GET", "/goform/getVarManageExtDataForm?arg=" + JSON.stringify(setval) );
            xhr.send();
        }
    } else {
        alert("�������б��У�ѡ��Ҫ�޸ĵ�ѡ��ٽ��ж�ȡ");
    }
}

function varExtTableItemRemoveAll()
{
	var table = window.document.getElementById("rtu_var_ext_table");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function onExtTableItemClick(tb,row)
{
    for (var i = 0; i < tb.rows.length; i++) {
        if( xVarManageExtDataBase[i].en > 0 ) {
            tb.rows[i].style.background="#F5F5F5";
        } else {
            tb.rows[i].style.background="#AAAAAA";
        }
    }
    row.style.background="#F007f0";

    setValue('var_ext_id', row.rowIndex);
    setValue('var_ext_enable', xVarManageExtDataBase[row.rowIndex].en);
    setValue('var_ext_name', xVarManageExtDataBase[row.rowIndex].na);
    setValue('var_ext_alias', xVarManageExtDataBase[row.rowIndex].al);
    setValue('var_ext_vartype', xVarManageExtDataBase[row.rowIndex].vt);
    setValue('var_ext_varsize', xVarManageExtDataBase[row.rowIndex].vs);
    setValue('var_ext_devtype', xVarManageExtDataBase[row.rowIndex].dt + "|" + xVarManageExtDataBase[row.rowIndex].pt);
    setValue('var_ext_addr', xVarManageExtDataBase[row.rowIndex].ad);
    setValue('var_ext_slaveaddr', xVarManageExtDataBase[row.rowIndex].sa);
    setValue('var_ext_extaddr', xVarManageExtDataBase[row.rowIndex].ea);
    setValue('var_ext_extaddrofs', xVarManageExtDataBase[row.rowIndex].ao);
    setValue('var_ext_varrw', xVarManageExtDataBase[row.rowIndex].rw);
    setValue('var_ext_interval', xVarManageExtDataBase[row.rowIndex].it);
    
    onVarExtVartypeChange( window.document.getElementById("var_ext_vartype") );
}

function varExtGetProtoName(dev,proto)
{
    var str = "";
    switch(dev) {
    case 0: {
        switch(proto) {
        case 0: return "UART1_Modbus_RTU";
        }
        break;
    }
    case 1: {
        switch(proto) {
        case 0: return "UART2_Modbus_RTU";
        }
        break;
    }
    case 2: {
        switch(proto) {
        case 0: return "UART3_Modbus_RTU";
        }
        break;
    }
    case 3: {
        switch(proto) {
        case 0: return "UART4_Modbus_RTU";
        }
        break;
    }
    case 4: {
        switch(proto) {
        case 0: return "Net_Modbus_TCP_1";
        case 1: return "Net_Modbus_TCP_2";
        case 2: return "Net_Modbus_TCP_3";
        case 3: return "Net_Modbus_TCP_4";
        }
        break;
    }
    case 5: {
        switch(proto) {
        case 0: return "Zigbee_Modbus_RTU";
        }
        break;
    }
    case 6: {
        switch(proto) {
        case 0: return "GPRS_Modbus_TCP_1";
        case 1: return "GPRS_Modbus_TCP_2";
        case 2: return "GPRS_Modbus_TCP_3";
        case 3: return "GPRS_Modbus_TCP_4";
        }
        break;
    }
    }
    
    return "ERROR";
}

function varExtGetVarTypeName(type)
{
    switch(type){
    case 0: return "BIT";
    case 1: return "INT8";
    case 2: return "UINT8";
    case 3: return "INT16";
    case 4: return "UINT16";
    case 5: return "INT32";
    case 6: return "UINT32";
    case 7: return "FLOAT";
    case 8: return "DOUBLE";
    case 9: return "ARRAY";
    default: return "ERROR";
    }
}

function varExtTableAddItem(enable,name,alias,type,size,interval,value,protodev,proto)
{
	var table = window.document.getElementById("rtu_var_ext_table");
	var row = table.insertRow(table.rows.length);
    row.onclick = function(){ onExtTableItemClick( table, row ); };
    var obj = row.insertCell(0);
	obj.width = "10px"; obj.className = "tc";
    obj.innerHTML = table.rows.length - 1;
	obj = row.insertCell(1);
	obj.width = "10px"; obj.className = "tc";
    obj.innerHTML = enable != 0 ? "��Ч" : "��Ч";
	obj = row.insertCell(2);
	obj.width = "30px"; obj.className = "tc";
    obj.innerHTML = name;
	obj = row.insertCell(3);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = alias;
	obj = row.insertCell(4);
	obj.width = "10px"; obj.className = "tc";
    obj.innerHTML = varExtGetVarTypeName(type);
	obj = row.insertCell(5);
	obj.width = "10px"; obj.className = "tc";
    obj.innerHTML = size;
	obj = row.insertCell(6);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = enable != 0 ? interval : "--";
	obj = row.insertCell(7);
	obj.width = "35px"; obj.className = "tc";
    obj.innerHTML = enable != 0 ? value : "--";
	obj = row.insertCell(8);
	obj.width = "60px"; obj.className = "tc";
    obj.innerHTML = enable != 0 ? varExtGetProtoName(protodev, proto) : "--";
}

function onVarExtVartypeChange(obj)
{
    if( obj.selectedIndex < 3 ) {
        setValue("var_ext_varsize", 1 );
    } else if( obj.selectedIndex < 5 ) {
        setValue("var_ext_varsize", 2 );
    } else if( obj.selectedIndex < 8 ) {
        setValue("var_ext_varsize", 4 );
    } else if( obj.selectedIndex == 8 ) {
        setValue("var_ext_varsize", 8 );
    }
    
    if( obj.selectedIndex < 9 ) {
        setEnable("var_ext_varsize", false );
    } else {
        setEnable("var_ext_varsize", true );
    }
}

function setVarExtInfo()
{
    var obj = window.document.getElementById("var_ext_id");
    var id = -1;
    if( obj != null && obj.value.length > 0 ) {
        id = Number(obj.value);
    }
    
    if( id >= 0 && id <= 64 ) {
        
        onVarExtVartypeChange( window.document.getElementById("var_ext_vartype") );
        var varsize = getNumber('var_ext_varsize')
        if( varsize > 8 ) {
            alert("��󳤶�Ϊ8�ֽ�,���޸ĺ����±���");
            return ;
        }
        
        var addr = getNumber('var_ext_addr');

        if( addr < 1024 || addr > 2048 ) {
            alert("�ڲ�ӳ���ַ��Χ(1024->2048), ���޸ĺ����±���");
            return ;
        }
        
        var slaveaddr = getNumber('var_ext_slaveaddr');

        if( slaveaddr < 0 || slaveaddr > 255 ) {
            alert("Modbus�ӻ���ַ��Χ(0->255), ���޸ĺ����±���");
            return ;
        }
            
        var proto = getValue("var_ext_devtype").split("|");
        var setval = {
            n:id, 
            en:getNumber('var_ext_enable'), 
            na:getValue('var_ext_name'), 
            al:getValue('var_ext_alias'), 
            vt:getNumber('var_ext_vartype'), 
            vs:getNumber('var_ext_varsize'), 
            dt:Number(proto[0]), 
            pt:Number(proto[1]), 
            ad:getNumber('var_ext_addr'), 
            sa:getNumber('var_ext_slaveaddr'), 
            ea:getNumber('var_ext_extaddr'), 
            ao:getNumber('var_ext_extaddrofs'), 
            rw:getNumber('var_ext_varrw'),
            it:getNumber('var_ext_interval')
        };

        xhr = createXMLHttpRequest();
        if (xhr) {
            xhr.onreadystatechange = function() {
                if( xhr.readyState==4 ) {
                    if( xhr.status==200 ) {
                        var res = JSON.parse(xhr.responseText);
                        if( res && 0 == res.ret ) {
                            alert( "���óɹ�" );
                        } else {
                            alert("����ʧ��,������");
                        }
                    } else {
                        alert("���ó�ʱ,������");
                    }
                }
            }
            xhr.open("GET", "/goform/setVarManageExtDataForm?arg=" + JSON.stringify(setval) );
            xhr.send();
        }
    } else {
        alert("�������б��У�ѡ��Ҫ�޸ĵ�ѡ��ٽ�������");
    }
}

function refreshProtoDevList(res)
{
    var protoDevList = window.document.getElementById("var_ext_devtype");
    protoDevList.options.length = 0;
    if( res.rs != null ) {
        for( var n = 0; n < res.rs.length; n++ ) {
            protoDevList.options.add(
                new Option(
                    varExtGetProtoName( res.rs[n].id, res.rs[n].po ), 
                    res.rs[n].id + "|" + res.rs[n].po
                )
            );
        }
    }
    if( res.net != null ) {
        for( var n = 0; n < res.net.length; n++ ) {
            protoDevList.options.add(
                new Option(
                    varExtGetProtoName( res.net[n].id, res.net[n].po ), 
                    res.net[n].id + "|" + res.net[n].po
                )
            );
        }
    }
    if( res.zigbee != null ) {
        for( var n = 0; n < res.zigbee.length; n++ ) {
            protoDevList.options.add(
                new Option(
                    varExtGetProtoName( res.zigbee[n].id, res.zigbee[n].po), 
                    res.zigbee[n].id + "|" + res.zigbee[n].po
                )
            );
        }
    }
    if( res.gprs != null ) {
        for( var n = 0; n < res.gprs.length; n++ ) {
            protoDevList.options.add(
                new Option(
                    varExtGetProtoName( res.gprs[n].id, res.gprs[n].po), 
                    res.gprs[n].id + "|" + res.gprs[n].po
                )
            );
        }
    }
}

function getProtoDevList()
{
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        xProtoDevList = res;
                        refreshProtoDevList( res );
                    } else {
                        alert("��ȡ����Э���б�ʧ��,������");
                    }
                } else {
                    alert("��ȡ����Э���б���ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getProtoManageForm?" );
		xhr.send();
	}
}

function refreshDevInfo(info)
{
    setValue('rtu_dev_id', info.id);
    setValue('rtu_dev_hw_ver', Number(Number(info.hw) / 100.0).toFixed(2));
    setValue('rtu_dev_sw_ver', Number(Number(info.sw) / 100.0).toFixed(2));
    setValue('rtu_dev_oem', info.om);
    setValue('rtu_dev_mac', info.mc);
    setValue('rtu_dev_time', info.dt);
}

function getDevInfo()
{
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        refreshDevInfo( res );
                    } else {
                        alert("��ȡ�豸��Ϣʧ��,������");
                    }
                } else {
                    alert("��ȡ�豸��Ϣ��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getDevInfoForm?" );
		xhr.send();
	}
}

function devTimeSync()
{
    var myDate = new Date();
    var setval = {
        ye:myDate.getFullYear(), 
        mo:(myDate.getMonth()+1), 
        da:myDate.getDate(), 
        dh:myDate.getHours(), 
        hm:myDate.getMinutes(), 
        ms:myDate.getSeconds()
    };
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        alert("��ʱ�ɹ�");
                    } else {
                        alert("��ʱʧ��,������");
                    }
                } else {
                    alert("��ʱ��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/setTimeForm?arg=" + JSON.stringify(setval) );
		xhr.send();
	}  
}

function refreshNetInfo(info)
{
    /*setValue('rtu_dev_id', info.id);
    setValue('rtu_dev_hw_ver', Number(Number(info.hw) / 100.0).toFixed(2));
    setValue('rtu_dev_sw_ver', Number(Number(info.sw) / 100.0).toFixed(2));
    setValue('rtu_dev_oem', info.om);
    setValue('rtu_dev_mac', info.mc);
    setValue('rtu_dev_time', info.dt);*/
    
    if( info.status != null ) {
        window.document.getElementById("lbl_netStatus").innerHTML=info.status;
    }
}

function getNetInfo()
{
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        refreshNetInfo( res );
                    } else {
                        alert("��ȡ������Ϣʧ��,������");
                    }
                } else {
                    alert("��ȡ������Ϣ��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getNetCfgForm?" );
		xhr.send();
	}
}

function getAllTcpipCfg()
{
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        xTcpipCfgList = res.list.concat();
                        for( var n = 0; n < res.list.length; n++ ) {
                            refreshTcpipCfg( 
                                n, 
                                res.list[n]
                            );
                        }
                        if( res.net != null ) {
                            refreshNetInfo(res.net);
                        }
                    } else {
                        alert("��ȡTCP/IP����ʧ��,������");
                    }
                } else {
                    alert("��ȡTCP/IP���ó�ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getTcpipCfgForm?arg={\"all\":1}" );
		xhr.send();
    }
}

function getTcpipCfg(i)
{
    var setval = { n:Number(i) };
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                        refreshTcpipCfg( i, res );
                    } else {
                        alert("��ȡTCP/IP����ʧ��,������");
                    }
                } else {
                    alert("��ȡTCP/IP���ó�ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/getTcpipCfgForm?arg=" + JSON.stringify(setval) );
		xhr.send();
    }
}

function refreshTcpipCfg(n,cfg)
{
    setValue('net_tcpip'+n+'_enable', cfg.en);
    setValue('net_tcpip'+n+'_type', cfg.tt);
    setValue('net_tcpip'+n+'_cs', cfg.cs);
    setValue('net_tcpip'+n+'_proto', cfg.pt);
    setValue('net_tcpip'+n+'_ms', cfg.ms);
    setValue('net_tcpip'+n+'_peer', cfg.pe);
    setValue('net_tcpip'+n+'_port', cfg.po);
}

function setTcpipCfg(i)
{
    var setval = {
        n:Number(i), 
        en:getNumber('net_tcpip' + i + '_enable'), 
        tt:getNumber('net_tcpip' + i + '_type'), 
        pt:getNumber('net_tcpip' + i + '_proto'), 
        cs:getNumber('net_tcpip' + i + '_cs'), 
        ms:getNumber('net_tcpip' + i + '_ms'), 
        pe:getValue('net_tcpip' + i + '_peer'), 
        po:getNumber('net_tcpip' + i + '_port')
    };
    
    xhr = createXMLHttpRequest();
    if (xhr) {
		xhr.onreadystatechange = function() {
            if( xhr.readyState==4 ) {
                if( xhr.status==200 ) {
                    var res = JSON.parse(xhr.responseText);
                    if( res && 0 == res.ret ) {
                    } else {
                        alert("����TCP/IP " + i + "ʧ��,������");
                    }
                } else {
                    alert("����TCP/IP " + i + "��ʱ,������");
                }
            }
        }
		xhr.open("GET", "/goform/setTcpipCfgForm?arg=" + JSON.stringify(setval) );
		xhr.send();
    }
}
