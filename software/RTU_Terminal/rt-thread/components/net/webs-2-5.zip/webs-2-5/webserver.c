/*
 * main.c -- Main program for the GoAhead WebServer (RT-Thread version)
 *
 * Copyright (c) Go Ahead Software Inc., 1995-2010. All Rights Reserved.
 *
 * See the file "license.txt" for usage and redistribution license requirements
 *
 */

/******************************** Description *********************************/

/*
 *  Main program for for the GoAhead WebServer. This is a demonstration
 *  main program to initialize and configure the web server.
 */

/********************************* Includes ***********************************/

#include "uemf.h"
#include "wsIntrn.h"
#include <lwip/sockets.h>

/*********************************** Locals ***********************************/
/*
 *  Change configuration here
 */

static char_t   *password = T("");  /* Security password */
static const int port = 80;			/* Server port */
static const int retries = 5;		/* Server port retries */
static int finished;				/* Finished flag */

/****************************** Forward Declarations **************************/

static int  initWebs();
static int  aspTest(int eid, webs_t wp, int argc, char_t **argv);
static int  websHomePageHandler(webs_t wp, char_t *urlPrefix, char_t *webDir,
                int arg, char_t* url, char_t* path, char_t* query);

#ifdef B_STATS
#error WARNING:  B_STATS directive is not supported in this OS!
#endif

/*********************************** Code *************************************/
/*
 *	Main -- entry point from RTT
 */

void webserver_thread_entry(void *parameter)
{
/*
 *  Initialize the memory allocator. Allow use of malloc and start 
 *  with a 60K heap.  For each page request approx 8KB is allocated.
 *  60KB allows for several concurrent page requests.  If more space
 *  is required, malloc will be used for the overflow.
 */
    bopen(NULL, (60 * 1024), B_USE_MALLOC);

/*
 *  Initialize the web server
 */
    if (initWebs() < 0) {
        return;
    }

/*
 *  Basic event loop. SocketReady returns true when a socket is ready for
 *  service. SocketSelect will block until an event occurs. SocketProcess
 *  will actually do the servicing.
 */
    while (!finished) {
        if (socketReady(-1) || socketSelect(-1, 2000)) {
            socketProcess(-1);
        }
        emfSchedProcess();
    }

/*
 *  Close the socket module, report memory leaks and close the memory allocator
 */
    websCloseServer();
    socketClose();
    bclose();
}

extern void devResetForm(webs_t wp, char_t *path, char_t *query);

extern void setDevInfoForm(webs_t wp, char_t *path, char_t *query);
extern void getDevInfoForm(webs_t wp, char_t *path, char_t *query);
extern void setDefaultMacForm(webs_t wp, char_t *path, char_t *query);
extern void setTimeForm(webs_t wp, char_t *path, char_t *query);

extern void getNetCfgForm(webs_t wp, char_t *path, char_t *query);
extern void setNetCfgForm(webs_t wp, char_t *path, char_t *query);

extern void setTcpipCfgForm(webs_t wp, char_t *path, char_t *query);
extern void getTcpipCfgForm(webs_t wp, char_t *path, char_t *query);

extern void getProtoManageForm(webs_t wp, char_t *path, char_t *query);

extern void setUartCfgForm(webs_t wp, char_t *path, char_t *query);
extern void getUartCfgForm(webs_t wp, char_t *path, char_t *query);

extern void getVarManageExtDataForm(webs_t wp, char_t *path, char_t *query);
extern void setVarManageExtDataForm(webs_t wp, char_t *path, char_t *query);

/******************************************************************************/
/*
 *  Initialize the web server.
 */
static int initWebs()
{
    //char        host[128]= "DJYOS_STACK";
    //char        *cp;
    //char_t      wbuf[128];

    //struct in_addr  addr;
/*
 *  Initialize the socket subsystem
 */
    socketOpen();

/*
 *  Configure the web server options before opening the web server
 */
    websSetDefaultDir("/");
    //addr.s_addr = INADDR_ANY;
    //cp = inet_ntoa(addr);
    //ascToUni(wbuf, cp, min(strlen(cp) + 1, sizeof(wbuf)));
    //websSetIpaddr(wbuf);
    //ascToUni(wbuf, host, min(strlen(host) + 1, sizeof(wbuf)));
    //websSetHost(wbuf);

/*
 *  Configure the web server options before opening the web server
 */
    websSetDefaultPage(T("setting.htm"));
    websSetPassword(password);

/* 
 *  Open the web server on the given port. If that port is taken, try
 *  the next sequential port for up to "retries" attempts.
 */
    websOpenServer(port, retries);

/*
 *  First create the URL handlers. Note: handlers are called in sorted order
 *  with the longest path handler examined first. Here we define the security 
 *  handler, forms handler and the default web page handler.
 */
    websUrlHandlerDefine(T(""), NULL, 0, websSecurityHandler, 
        WEBS_HANDLER_FIRST);
    websUrlHandlerDefine(T("/goform"), NULL, 0, websFormHandler, 0);
    websUrlHandlerDefine(T(""), NULL, 0, websDefaultHandler, 
        WEBS_HANDLER_LAST); 

    websFormDefine(T("devResetForm"), devResetForm);
   
    websFormDefine(T("getDevInfoForm"), getDevInfoForm);
    websFormDefine(T("setDevInfoForm"), setDevInfoForm);
    websFormDefine(T("setDefaultMacForm"), setDefaultMacForm);
    websFormDefine(T("setTimeForm"), setTimeForm);


    websFormDefine(T("getNetCfgForm"), getNetCfgForm);
    websFormDefine(T("setNetCfgForm"), setNetCfgForm);
    
    websFormDefine(T("getTcpipCfgForm"), getTcpipCfgForm);
    websFormDefine(T("setTcpipCfgForm"), setTcpipCfgForm);
    
    
    websFormDefine(T("getProtoManageForm"), getProtoManageForm);
    
    websFormDefine(T("setUartCfgForm"), setUartCfgForm);
    websFormDefine(T("getUartCfgForm"), getUartCfgForm);
    
    websFormDefine(T("getVarManageExtDataForm"), getVarManageExtDataForm);
    websFormDefine(T("setVarManageExtDataForm"), setVarManageExtDataForm);

    websUrlHandlerDefine(T("/"), NULL, 0, websHomePageHandler, 0); 
    return 0;
}

/******************************************************************************/
/*
 *  Test Javascript binding for ASP. This will be invoked when "aspTest" is
 *  embedded in an ASP page. See web/asp.asp for usage. Set browser to 
 *  "localhost/asp.asp" to test.
 */

static int aspTest(int eid, webs_t wp, int argc, char_t **argv)
{
    char_t  *name, *address;

    if (ejArgs(argc, argv, T("%s %s"), &name, &address) < 2) {
        websError(wp, 400, T("Insufficient args\n"));
        return -1;
    }

    return websWrite(wp, T("Name: %s, Address %s"), name, address);
}

/******************************************************************************/
/*
 *  Home page handler
 */

static int websHomePageHandler(webs_t wp, char_t *urlPrefix, char_t *webDir,
    int arg, char_t* url, char_t* path, char_t* query)
{
/*
 *  If the empty or "/" URL is invoked, redirect default URLs to the home page
 */
    if (*url == '\0' || gstrcmp(url, T("/")) == 0) {
        websRedirect(wp, T("setting.htm"));
        return 1;
    }
    return 0;
}


void webserver_start()
{
	rt_thread_t tid;

	tid = rt_thread_create("goahead",
		webserver_thread_entry, RT_NULL,
		2048, 10 ,10 );
	if (tid != RT_NULL) rt_thread_startup(tid);
}

#ifdef RT_USING_FINSH
#include <finsh.h>
FINSH_FUNCTION_EXPORT(webserver_start, start web server)
#endif


